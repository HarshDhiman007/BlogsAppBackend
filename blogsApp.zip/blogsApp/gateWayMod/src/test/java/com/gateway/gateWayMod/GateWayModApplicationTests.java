package com.gateway.gateWayMod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GateWayModApplicationTests {

	@Test
	void contextLoads() {
	}

}
